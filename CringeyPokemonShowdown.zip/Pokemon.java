
/**
*  Author: Evan Li
*  A class represents Pokemon, the instances can fight with each other.
*/
import java.lang.Math;

public class Pokemon {
  private String name;
  private String type;
	private int speed;
  // damage per attach, having 4 integers to randomly choose;
  private int[] damage;
	private int hp;  // i.e. health
  private int attack;
  private int defense;
  // Constructor 
  public Pokemon(String pokemonName, String pokemonType, 
                 int speedStat,int[] damageStat,int health, 
                 int attackStat, int defenseStat) {
    name = pokemonName;
    type = pokemonType;
    speed = speedStat;
    damage = damageStat;
    hp = health;
    attack = attackStat;
    defense = defenseStat;
  }
  public String getName() {
    return name;
  }
  public String getType() {
    return type;
  }
  public int getSpeed() {
    return speed;
  }
  public int[] getDamage() {
    return damage;
  }
  public int getHP() {
    return hp;
  }
  public void setHP(int health) {
    hp =  health;
  }
  public int getAttack() {
    return attack;
  }
  public int getDefense() {
    return defense;
  }

/**
* Using Math.random() to pick damage per attack
* @return randomly pick one of value in damage[] 
*/
  public int randomDamage() {
    double random = Math.random();
    if (random <= 0.25) {
      return damage[0];
    } 
    else if (random <= 0.5) {
      return damage[1];
    } 
    else if (random <= 0.75) {
      return damage[2];
    } 
    return damage[1];
  }

/**
* Outputs damage pokemon can occur to the opponent.
* @param opponentDefenseStat the defense ability of the opponent
* @return the demage it occurs to the opponent. 
*
*/ 
  public int calculateDamageOutput(int opponentDefenseStat) {
    int damagePerAttack = randomDamage();
    if(attack <= 70) {
      damagePerAttack *= 0.9;
      if(opponentDefenseStat <= 70) {
        damagePerAttack *= 0.95;
      }
      else if(opponentDefenseStat <= 100) {
        damagePerAttack *= 0.90;
      }
      else if(opponentDefenseStat <= 130) {
        damagePerAttack *= 0.85;
      }
      else {
        damagePerAttack *= 0.8;
      }
    }
    else if(attack <= 100) {
      damagePerAttack *= 1;
      if(opponentDefenseStat <= 70) {
        damagePerAttack *= 0.95;
      }
      else if(opponentDefenseStat <= 100) {
        damagePerAttack *= 0.9;
      }
      else if(opponentDefenseStat <= 130) {
        damagePerAttack *= 0.85;
      }
      else {
        damagePerAttack *= 0.8;
      }
    }
    else if(attack <= 130) {
      damagePerAttack *= 1.1;
      if(opponentDefenseStat <= 70) {
        damagePerAttack *= 0.95;
      }
      else if(opponentDefenseStat <= 100) {
        damagePerAttack *= 0.9;
      }
      else if(opponentDefenseStat <= 130) {
        damagePerAttack *= 0.85;
      }
      else {
        damagePerAttack *= 0.8;
      }
    }
    else {
      damagePerAttack *= 1.2;
      if(opponentDefenseStat <= 70) {
        damagePerAttack *= 0.95;
      }
      else if(opponentDefenseStat <= 100) {
        damagePerAttack *= 0.9;
      }
      else if(opponentDefenseStat <= 130) {
        damagePerAttack *= 0.85;
      }
      else {
        damagePerAttack *= 0.8;
      }
    
    }
    return damagePerAttack;
  }
/**
* Output the attack priority against a given pokemon.
* @param one the opponent pokemon
* @return boolean if the instance has higher priority to attack than the opponent
*
*/  
  public boolean hasAttackPriority(Pokemon one) {
      if(speed > one.speed) {
        return true;
      }
    return false;
  }

/**
* Output if the pokemon is fainted.
* @return true if health equals to or lower than zero
*
*/
  public boolean isFainted() {
    return hp <= 0;
  }

/**
* Output pokemon's name
* @return name of pokemon
*
*/
  public String toString() {
    return name;
  }
}