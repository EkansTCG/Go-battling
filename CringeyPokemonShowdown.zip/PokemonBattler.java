/**
*  Author: Evan Li
*  A class represents PokemonBattler that can hold two pokemons, and directs the flow of 
*  the battle between them.
*/


public class PokemonBattler {
  Pokemon pokemon1;
  Pokemon pokemon2;
  public PokemonBattler(Pokemon pocketMonster1, Pokemon pocketMonster2) {
    pokemon1 = pocketMonster1;
    pokemon2 = pocketMonster2;
  }
  
/**
* Starts the battle of two pokemons 
*/
  public void battle() {
    Pokemon attacker, defender;
    if (pokemon1.hasAttackPriority(pokemon2)) {
      attacker = pokemon1;
      defender = pokemon2;
    } else {
      attacker = pokemon2;
      defender = pokemon1;
  
    }

  System.out.println("Pokemon Battle Starts between " + attacker + " and " + defender);
    
  while(!defender.isFainted()) {
    int damage = attacker.calculateDamageOutput(defender.getDefense());
    defender.setHP(defender.getHP() - damage);
    System.out.println(attacker + " dealt " + damage + " damage to " + defender);
   
    // check if defender didn't faint, so continue the battle;
    if(!defender.isFainted()) {
      Pokemon temp = attacker;
      attacker = defender;
      defender = temp;
    }
  }
  System.out.println(attacker + " is the winner!! :)");
  }
}