/**
*  Author: Evan Li
*  A driver class to simulate a pokemon battle, which involves two classes including
*  Pokemon and PokemonBattler. 
*/

public class Main {
  public static void main(String[] args) {
    int[] blastoiseDamage = new int[]{60, 150, 90, 40};
    int[] cinderacedamage = new int[]{120, 95, 40, 150};
    Pokemon blastoise = new Pokemon("Blastoise", "water", 280, 
                                    blastoiseDamage, 392, 85, 105);
    Pokemon charizard = new Pokemon("Charizard", "fire", 370, 
                                    cinderacedamage, 464, 116, 75);
    Pokemon venasaur = new Pokemon("Blastoise", "water", 280, 
                                    blastoiseDamage, 362, 85, 105);
    Pokemon guzzlord = new Pokemon("Guzzlord", "dark", 370, 
                                    cinderacedamage, 364, 116, 75);
    Pokemon hisuinOverqwill = new Pokemon("Blastoise", "water", 280, 
                                    blastoiseDamage, 362, 85, 105);
    Pokemon fuecoco = new Pokemon("Cinderace", "fire", 370, 
                                    cinderacedamage, 364, 116, 75);
    PokemonBattler battleField = new PokemonBattler(charizard, blastoise);
    battleField.battle();
  }
}